import { Component } from '@angular/core';

@Component({
  selector: 'app-all-departments',
  standalone: false,
  
  templateUrl: './all-departments.component.html',
  styleUrl: './all-departments.component.css'
})
export class AllDepartmentsComponent {

}
