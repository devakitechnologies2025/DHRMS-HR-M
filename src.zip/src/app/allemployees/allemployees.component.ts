import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router, RouterModule } from '@angular/router';

@Component({
  selector: 'app-allemployees',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './allemployees.component.html',
  styleUrl: './allemployees.component.css',
})

export class AllemployeesComponent implements OnInit {
  emp: any[] = [
    { name: 'John Doe', id: 'E001', department: 'HR', designation: 'Manager', mode: 'Work From Home', assigned: 'Yes', project: 'Project Alpha' },
    { name: 'Jane Smith', id: 'E002', department: 'IT', designation: 'Developer', mode: 'Office', assigned: 'No', project: 'Project Beta' },
    { name: 'Paul Adams', id: 'E003', department: 'Finance', designation: 'Accountant', mode: 'Hybrid', assigned: 'Yes', project: 'Project Gamma' },
    { name: 'Mary Johnson', id: 'E004', department: 'HR', designation: 'Recruiter', mode: 'Office', assigned: 'No', project: 'Project Alpha' },
    { name: 'James Brown', id: 'E005', department: 'Marketing', designation: 'SEO Specialist', mode: 'Work From Home', assigned: 'Yes', project: 'Project Beta' },
    { name: 'John Doe', id: 'E006', department: 'HR', designation: 'Manager', mode: 'Work From Home', assigned: 'Yes', project: 'Project Alpha' },
    { name: 'Jane Smith', id: 'E007', department: 'IT', designation: 'Developer', mode: 'Office', assigned: 'No', project: 'Project Beta' },
    { name: 'Paul Adams', id: 'E008', department: 'Finance', designation: 'Accountant', mode: 'Hybrid', assigned: 'Yes', project: 'Project Gamma' },
    { name: 'Mary Johnson', id: 'E009', department: 'HR', designation: 'Recruiter', mode: 'Office', assigned: 'No', project: 'Project Alpha' },
    { name: 'James Brown', id: 'E010',department: 'Marketing', designation: 'SEO Specialist', mode: 'Work From Home', assigned: 'Yes', project: 'Project Beta' },
    { name: 'John Doe', id: 'E001', department: 'HR', designation: 'Manager', mode: 'Work From Home', assigned: 'Yes', project: 'Project Alpha' },
    { name: 'Jane Smith', id: 'E002', department: 'IT', designation: 'Developer', mode: 'Office', assigned: 'No', project: 'Project Beta' },
    { name: 'Paul Adams', id: 'E003', department: 'Finance', designation: 'Accountant', mode: 'Hybrid', assigned: 'Yes', project: 'Project Gamma' },
    { name: 'Mary Johnson', id: 'E004', department: 'HR', designation: 'Recruiter', mode: 'Office', assigned: 'No', project: 'Project Alpha' },
    { name: 'James Brown', id: 'E005', department: 'Marketing', designation: 'SEO Specialist', mode: 'Work From Home', assigned: 'Yes', project: 'Project Beta' },
    
  ];

  // Pagination
  currentPage = 1;
  itemsPerPage = 10;
  totalRecords = this.emp.length;
  recordsRange = '';
  pagedEmployees: any[] = [];
  showFilterSection: boolean = false;

  // Filters
  departments = ['HR', 'IT', 'Finance', 'Marketing', 'Sales', 'Engineering', 'Support', 'Operations', 'Admin', 'Legal'];
  selectedDepartments: string[] = [];
  
  projects = ['Project Alpha', 'Project Beta', 'Project Gamma', 'Project Delta', 'Project Omega'];
  selectedProjects: string[] = [];
  
  workModes = ['Work From Home', 'Office', 'Hybrid'];
  selectedWorkMode: string = '';
  
  // Function to handle department selection (Checkbox)
  toggleDepartmentSelection(dept: string): void {
    const index = this.selectedDepartments.indexOf(dept);
    if (index === -1) {
      this.selectedDepartments.push(dept);
    } else {
      this.selectedDepartments.splice(index, 1);
    }
  }
  
 
  
  selectWorkMode(mode: string) {
    this.selectedWorkMode = mode;
  }
  
  toggleProjectSelection(project: string) {
    if (this.selectedProjects.includes(project)) {
      this.selectedProjects = this.selectedProjects.filter(p => p !== project);
    } else {
      this.selectedProjects.push(project);
    }
  }


  constructor(private router: Router, private route: ActivatedRoute) {}

  ngOnInit(): void {
    this.updatePagedEmployees();
    this.updateRecordsRange();
  }

  // Update the employees shown per page
  updatePagedEmployees(): void {
    const start = (this.currentPage - 1) * this.itemsPerPage;
    const end = start + this.itemsPerPage;
    this.pagedEmployees = this.emp.slice(start, end);
  }

  // Handle pagination
  goToPage(page: number): void {
    if (page < 1 || (page - 1) * this.itemsPerPage >= this.totalRecords) return;
    this.currentPage = page;
    this.updatePagedEmployees();
    this.updateRecordsRange();
  }

  // Update range display (e.g., "1 to 10 out of 20 records")
  updateRecordsRange(): void {
    const start = (this.currentPage - 1) * this.itemsPerPage;
    const end = Math.min(this.currentPage * this.itemsPerPage, this.totalRecords);
    this.recordsRange = `${start + 1} to ${end} out of ${this.totalRecords} records`;
  }

  // Handle viewing employee details
  viewEmployee(employee: any): void {
    console.log('Viewing:', employee);
  }

  // Handle editing employee details
  editEmployee(employee: any): void {
    console.log('Editing:', employee);
  }

  // Handle deleting an employee
  deleteEmployee(employeeId: string): void {
    if (confirm('Are you sure you want to delete this employee?')) {
      this.emp = this.emp.filter(emp => emp.id !== employeeId);
      this.totalRecords = this.emp.length;
      this.updatePagedEmployees();
      this.updateRecordsRange();
      alert('Employee deleted successfully.');
    }
  }

  // Handle changing records per page
  onRecordsChange(event: any): void {
    this.itemsPerPage = parseInt(event.target.value, 10);
    this.currentPage = 1;
    this.updatePagedEmployees();
    this.updateRecordsRange();
  }

  // Toggle filter modal visibility
  toggleFilterSection(): void {
    this.showFilterSection = !this.showFilterSection;
    document.body.classList.toggle('modal-open', this.showFilterSection);
  }



  // Apply filters based on selections
  applyFilters(): void {
    console.log('Filters applied:', {
      Departments: this.selectedDepartments,
      Projects: this.selectedProjects,
      WorkMode: this.selectedWorkMode,
    });

    this.showFilterSection = false;
  }

  // Reset filters
  resetFilters(): void {
    this.selectedDepartments = [];
    this.selectedProjects = [];
    this.selectedWorkMode = '';
    console.log('Filters reset');
  }
  // Function to cancel filters and close the filter modal
cancelFilters(): void {
  this.showFilterSection = false;
}

}
